"""EEI application packages."""

