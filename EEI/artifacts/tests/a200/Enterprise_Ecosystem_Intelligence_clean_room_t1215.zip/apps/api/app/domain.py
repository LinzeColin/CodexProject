from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any, Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .domain_repository import CatalogRepository, DomainRepository, NotFoundError, RepositoryError
from .settings import get_settings

router = APIRouter(prefix="/v1", tags=["domain"])

EntityType = Literal[
    "legal_entity",
    "brand",
    "security",
    "fund",
    "government_body",
    "person",
    "theme",
    "facility",
    "product",
    "business_segment",
    "industry",
    "contract",
    "standard",
    "asset",
]
PathType = Literal[
    "shortest",
    "upstream",
    "downstream",
    "control",
    "capital",
    "policy",
    "bottleneck",
]


class FocusRef(BaseModel):
    object_type: Literal["entity", "industry", "theme", "facility"]
    object_id: UUID


class GraphBudget(BaseModel):
    max_nodes: int = Field(default=42, ge=1, le=500)
    max_edges: int = Field(default=64, ge=1, le=2000)
    expand_nodes: int = Field(default=12, ge=1, le=100)


class ExploreRequest(BaseModel):
    session_id: UUID | None = None
    focus: FocusRef
    active_layers: list[str] = Field(default_factory=lambda: ["supply_chain_operations"])
    direction: Literal["both", "upstream", "downstream", "in", "out"] = "both"
    hops: int = Field(default=1, ge=1, le=2)
    as_of: datetime | None = None
    scoring_profile_version_id: UUID | None = None
    filters: dict[str, Any] = Field(default_factory=dict)
    budget: GraphBudget = Field(default_factory=GraphBudget)


class RerootRequest(BaseModel):
    session_id: UUID
    new_focus_entity_id: UUID
    inherit_state: bool = True
    open_in_new_workspace: bool = False


class ExpandRequest(BaseModel):
    session_id: UUID
    anchor_entity_id: UUID
    direction: Literal["both", "upstream", "downstream", "in", "out"]
    layers: list[str]
    budget: GraphBudget


class WatchlistCreate(BaseModel):
    name: str = Field(min_length=1)
    description: str | None = None
    default_scoring_profile_version_id: UUID | None = None


class WatchlistItem(BaseModel):
    object_type: Literal["entity", "industry", "theme", "facility"]
    object_id: UUID
    labels: list[str] = Field(default_factory=list)
    note: str | None = None
    saved_state: dict[str, Any] = Field(default_factory=dict)


def get_repository() -> DomainRepository:
    settings = get_settings()
    if not settings.database_url:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="DATABASE_URL is required for domain API endpoints",
        )
    return DomainRepository(settings.database_url)


RepositoryDependency = Annotated[DomainRepository, Depends(get_repository)]
CatalogRepositoryDependency = Annotated[CatalogRepository, Depends(CatalogRepository)]


def translate_repository_error(error: RepositoryError) -> HTTPException:
    if isinstance(error, NotFoundError):
        return HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    return HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(error))


@router.get("/home")
def get_home(repository: RepositoryDependency) -> dict[str, Any]:
    try:
        return repository.list_home()
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.get("/catalogs")
def list_catalogs(repository: CatalogRepositoryDependency) -> dict[str, Any]:
    return repository.list_catalogs()


@router.get("/catalogs/{catalogKey}", response_model=None)
def get_catalog(
    catalogKey: str,
    repository: CatalogRepositoryDependency,
    format: Literal["json", "csv"] = Query(default="json"),
) -> dict[str, Any] | FileResponse:
    try:
        if format == "csv":
            csv_path = repository.csv_path_for_key(catalogKey)
            return FileResponse(
                csv_path,
                media_type="text/csv",
                filename=csv_path.name,
            )
        return repository.get_catalog(catalogKey)
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.get("/system/object-scope")
def get_object_scope(repository: CatalogRepositoryDependency) -> dict[str, Any]:
    return repository.object_scope()


@router.get("/entities")
def search_entities(
    repository: RepositoryDependency,
    q: Annotated[str | None, Query()] = None,
    type: Annotated[EntityType | None, Query()] = None,
    limit: Annotated[int, Query(ge=1, le=100)] = 20,
) -> list[dict[str, Any]]:
    try:
        return repository.search_entities(query=q, entity_type=type, limit=limit)
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.get("/entities/{entityId}")
def get_entity(entityId: UUID, repository: RepositoryDependency) -> dict[str, Any]:
    try:
        return repository.get_entity(entityId)
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.get("/industries")
def list_industries(
    repository: RepositoryDependency,
    parent: Annotated[UUID | None, Query()] = None,
) -> list[dict[str, Any]]:
    return repository.list_industries(parent=parent)


@router.get("/industries/{industryId}/landscape")
def get_industry_landscape(
    industryId: UUID,
    repository: RepositoryDependency,
    as_of: Annotated[datetime | None, Query()] = None,
    profile: Annotated[UUID | None, Query()] = None,
) -> dict[str, Any]:
    try:
        return repository.get_industry_landscape(
            industry_id=industryId,
            as_of=as_of,
            profile_id=profile,
        )
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.post("/explore")
def start_or_restore_exploration(
    payload: ExploreRequest,
    repository: RepositoryDependency,
) -> dict[str, Any]:
    try:
        return repository.start_exploration(payload.model_dump(mode="json"))
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.post("/explore/reroot")
def reroot_exploration(
    payload: RerootRequest,
    repository: RepositoryDependency,
) -> dict[str, Any]:
    try:
        return repository.reroot_exploration(payload.model_dump(mode="json"))
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.post("/explore/expand")
def expand_exploration(
    payload: ExpandRequest,
    repository: RepositoryDependency,
) -> dict[str, Any]:
    try:
        return repository.expand_exploration(payload.model_dump(mode="json"))
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.get("/paths")
def find_relationship_paths(
    repository: RepositoryDependency,
    from_entity_id: Annotated[UUID, Query(alias="from")],
    to_entity_id: Annotated[UUID, Query(alias="to")],
    path_type: Annotated[PathType, Query()] = "shortest",
    max_length: Annotated[int, Query(ge=1, le=8)] = 4,
    as_of: Annotated[datetime | None, Query()] = None,
) -> dict[str, Any]:
    try:
        return repository.find_relationship_paths(
            from_entity_id=from_entity_id,
            to_entity_id=to_entity_id,
            path_type=path_type,
            max_length=max_length,
            as_of=as_of,
        )
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.get("/watchlists")
def list_watchlists(repository: RepositoryDependency) -> list[dict[str, Any]]:
    return repository.list_watchlists()


@router.post("/watchlists", status_code=status.HTTP_201_CREATED)
def create_watchlist(
    payload: WatchlistCreate,
    repository: RepositoryDependency,
) -> dict[str, Any]:
    try:
        return repository.create_watchlist(
            name=payload.name,
            description=payload.description,
            default_scoring_profile_version_id=payload.default_scoring_profile_version_id,
        )
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.get("/watchlists/{watchlistId}")
def get_watchlist(watchlistId: UUID, repository: RepositoryDependency) -> dict[str, Any]:
    try:
        return repository.get_watchlist(watchlistId)
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.post("/watchlists/{watchlistId}/items", status_code=status.HTTP_201_CREATED)
def add_watchlist_item(
    watchlistId: UUID,
    payload: WatchlistItem,
    repository: RepositoryDependency,
) -> dict[str, Any]:
    try:
        return repository.add_watchlist_item(
            watchlistId,
            object_type=payload.object_type,
            object_id=payload.object_id,
            labels=payload.labels,
            note=payload.note,
            saved_state=payload.saved_state,
        )
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc


@router.delete("/watchlists/{watchlistId}/items", status_code=status.HTTP_204_NO_CONTENT)
def remove_watchlist_item(
    watchlistId: UUID,
    object_type: Literal["entity", "industry", "theme", "facility"],
    object_id: UUID,
    repository: RepositoryDependency,
) -> Response:
    try:
        repository.remove_watchlist_item(
            watchlistId,
            object_type=object_type,
            object_id=object_id,
        )
    except RepositoryError as exc:
        raise translate_repository_error(exc) from exc
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/changes")
def list_changes(
    repository: RepositoryDependency,
    since: datetime | None = None,
    change_type: str | None = None,
) -> list[dict[str, Any]]:
    return repository.list_changes(since=since, change_type=change_type)


@router.get("/audit-logs")
def list_audit_logs(
    repository: RepositoryDependency,
    object_type: str | None = None,
    object_id: UUID | None = None,
    since: datetime | None = None,
) -> list[dict[str, Any]]:
    return repository.list_audit_logs(object_type=object_type, object_id=object_id, since=since)


@router.get("/scoring/profiles")
def list_scoring_profiles(repository: RepositoryDependency) -> list[dict[str, Any]]:
    return repository.list_scoring_profiles()


@router.get("/calibrations")
def list_calibrations(repository: RepositoryDependency) -> list[dict[str, Any]]:
    return repository.list_calibrations()


@router.post("/calibrations/run", status_code=status.HTTP_202_ACCEPTED)
def run_calibration(repository: RepositoryDependency) -> dict[str, Any]:
    return repository.queue_calibration()
