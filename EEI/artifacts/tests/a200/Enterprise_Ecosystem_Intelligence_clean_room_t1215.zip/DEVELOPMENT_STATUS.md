# 开发任务、已解决/未解决与执行状态

## 当前结论

| 层级 | 当前状态 |
|---|---|
| 需求、架构、目录、模型与验收 | 已完成 Task Pack 规格 |
| 高保真交互原型 | 已完成，用 fixture 演示 |
| 生产代码与真实数据库 | T1300 PostgreSQL 生产迁移与版本层已实现；T1301 官方锚点 ingestion 基础层进行中；生产 API 和服务合同仍未达 MVP |
| 真实数据接入与企业事实 | T1301/A202 进行中；curated official anchors 与 Golden Vertical fact candidates 已入库合约化，但 live/full-text 采集、独立来源交叉验证和事实发布未完成，不得把候选数据当事实 |
| GitHub 治理模板与校验 | 已包含，推送仓库后启用 |

当前共有 **130 个产品开发任务**、**211 条验收标准**、**53 项风险**。新增 T1300-T1309/A201-A211 来自 v5 审查和用户当前待开发清单；T1300/A201 已关闭，T1301/A202 进行中但未关闭，T1302-T1309/A203-A211 仍未完成，避免把规格/原型或部分 ingestion 基础层误报为生产 MVP 完成。

## 已解决的关键决策（7）

- 默认首页、递归主体探索、数据底座、模型修改流程、14 天校准、视觉覆盖目标、文档治理方式均已冻结。

## v5 同步后仍阻断 v0.1 的生产项（9 个未关闭；T1301 进行中）

1. 真实数据采集、实体解析和证据链：官方锚点与 Golden Vertical 候选事实层已开始，live/full-text、正式事实发布和人工复核批准未完成。
2. 生产 API、递归图查询和评分服务。
3. 模型配置版本、事务性激活和原子全局刷新。
4. 后台调度、自动唤醒、幂等、重试和 dead-letter。
5. 服务端保存视图、冲突控制和恢复。
6. 10k、100k、1m 关系规模测试。
7. 4 小时和 24 小时 soak 测试。
8. 生产组件化前端、真实路由和真实控件连接。
9. EEI 正式品牌法律与市场清权。

已关闭：T1300/A201 PostgreSQL 可回滚迁移、data snapshot、fact version、fact evidence、时间有效性和版本层 schema。

进行中：T1301/A202 curated official NVIDIA/ASML source snapshots, raw snapshots, entity resolution candidates, Golden Vertical fact candidates, review queue and ingestion evidence chain.

## 仍未解决（7）

- 部署与预算、身份认证、商业数据许可、生产数据规模、图渲染库最终基准、战略模型有效性、140 个对象的真实关系接入。

## 状态文件

- `data/task_backlog.csv`：Codex 开发任务、依赖、Gate、Acceptance ID。
- `data/development_status_ledger.csv`：规格/原型/实现/验证四种状态。
- `data/resolved_unresolved_register.csv`：决策、Open issue、Deferred。
- `data/release_gate_catalog.csv`：G0-G9 进入/退出和停止条件。
- `docs/phase/V5_TASK_PACK_SYNCHRONIZATION.md`：v5 压缩包研究、生产缺口和 T1300-T1309/A201-A211 映射。

Codex 每完成一个任务，必须同步状态、测试证据、风险和验收，不得只在聊天中说明。
